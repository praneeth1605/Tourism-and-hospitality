from django.apps import AppConfig


class ProviderappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'providerapp'
