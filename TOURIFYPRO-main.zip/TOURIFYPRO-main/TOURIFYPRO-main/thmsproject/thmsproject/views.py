from django.http import HttpResponse
from django.shortcuts import render

"""
def demofn(request):
    return HttpResponse("TOuRISM and hospitality management system")

def demofn1(request):
    return HttpResponse("<font color = 'blue'>TOuRISM and hospitality management system<font>")
"""


"""
def checkprovlogin(request):

    provuname = request.GET['username']
    provpwd = request.GET['pwd']

    data = provuname+","+provpwd

    return HttpResponse(data)




"""
